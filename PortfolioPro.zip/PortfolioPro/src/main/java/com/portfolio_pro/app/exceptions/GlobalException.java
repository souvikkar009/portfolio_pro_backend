package com.portfolio_pro.app.exceptions;

import java.time.LocalDateTime;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.portfolio_pro.app.dtos.ErrorDetails;

@ControllerAdvice
public class GlobalException {
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ErrorDetails> bookExceptionHandler(UserException userException, WebRequest webRequest) {
		ErrorDetails errorDetails = new ErrorDetails(userException.getMessage(), webRequest.getDescription(false),
				LocalDateTime.now());
		return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(PortfolioException.class)
	public ResponseEntity<ErrorDetails> customerExceptionHandler(PortfolioException portfolioException, WebRequest webRequest) {
		ErrorDetails errorDetails = new ErrorDetails(portfolioException.getMessage(), webRequest.getDescription(false),
				LocalDateTime.now());
		return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorDetails> otherExceptionHandler(Exception exception, WebRequest webRequest){
		
		ErrorDetails errorDetails = new ErrorDetails(exception.getMessage(), webRequest.getDescription(false), LocalDateTime.now());
		
		return new ResponseEntity<ErrorDetails>(errorDetails, HttpStatus.BAD_REQUEST);
	}
}
