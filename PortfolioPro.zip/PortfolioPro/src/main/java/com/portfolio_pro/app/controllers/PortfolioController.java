package com.portfolio_pro.app.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.portfolio_pro.app.dtos.CreateFirstPortfolioDto;
import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.services.PortfolioServices;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/portfolios")
public class PortfolioController {

	@Autowired
	PortfolioServices portfolioServices;

	@PostMapping("/create-first")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<Portfolio> createFirstPortfolio(@RequestBody CreateFirstPortfolioDto createFirstPortfolioDto,
			HttpServletRequest httpServletRequest) throws UserException, PortfolioException {
		return new ResponseEntity<>(portfolioServices.createFirstPortfolio(createFirstPortfolioDto, httpServletRequest),
				HttpStatus.CREATED);
	}

	@GetMapping("/all")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<List<Portfolio>> getAllPortfoliosByUsername(HttpServletRequest httpServletRequest)
			throws UserException, PortfolioException {
		return new ResponseEntity<List<Portfolio>>(portfolioServices.getPortfoliosByUsername(httpServletRequest),
				HttpStatus.OK);
	}

	@GetMapping("/one/{portfolioId}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Portfolio> getPortfoliobyUserAndPortfolioId(HttpServletRequest httpServletRequest,
			@PathVariable Long portfolioId) throws UserException, PortfolioException {
		return new ResponseEntity<Portfolio>(
				portfolioServices.getPortfolioByUserAndPorfolioId(portfolioId, httpServletRequest), HttpStatus.OK);
	}

	@DeleteMapping("/remove/{portfolioId}")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public ResponseEntity<String> deletePortfolioByUserAndPortfolioId(HttpServletRequest httpServletRequest,
			@PathVariable Long portfolioId) throws UserException, PortfolioException {
		return new ResponseEntity<String>(
				portfolioServices.deletePortfolioByUserAndPortfolioId(portfolioId, httpServletRequest),
				HttpStatus.ACCEPTED);
	}
}
