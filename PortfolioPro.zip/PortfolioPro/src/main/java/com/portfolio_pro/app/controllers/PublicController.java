package com.portfolio_pro.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.services.PublicServices;


@RestController
@RequestMapping("/api/public")
public class PublicController {
	
	@Autowired
	PublicServices publicServices;
	
	@GetMapping("/{username}/{portfolioId}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Portfolio> getPortfolioByUsernameAndPortfolioId(@PathVariable String username, @PathVariable Long portfolioId) throws UserException, PortfolioException{
		return new ResponseEntity<Portfolio>(publicServices.getPortfolioByUsernameAndPortfolioId(username, portfolioId), HttpStatus.OK);
	}
}
