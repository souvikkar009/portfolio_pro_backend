package com.portfolio_pro.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.portfolio_pro.app.dtos.UserSigninDto;
import com.portfolio_pro.app.dtos.UserSignupDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.services.AuthServices;

import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	@Autowired
	AuthServices authServices;
	
	@PostMapping("/signup")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<User> signup(@RequestBody UserSignupDto userSignupDto) throws UserException {
		return new ResponseEntity<User>(authServices.signupUser(userSignupDto), HttpStatus.CREATED);
	}
	
	@PostMapping("/signin")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<String> signin(@RequestBody UserSigninDto userSigninDto, HttpServletResponse httpServletResponse) throws UserException{
		return new ResponseEntity<String>(authServices.signinUser(userSigninDto, httpServletResponse), HttpStatus.OK);
	}
}
