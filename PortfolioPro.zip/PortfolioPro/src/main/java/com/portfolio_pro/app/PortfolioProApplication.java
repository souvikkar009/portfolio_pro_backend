package com.portfolio_pro.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioProApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioProApplication.class, args);
	}

}
