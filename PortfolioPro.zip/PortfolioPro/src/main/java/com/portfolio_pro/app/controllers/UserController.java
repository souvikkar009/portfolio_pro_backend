package com.portfolio_pro.app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.portfolio_pro.app.dtos.UpdateUserDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.services.UserServices;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/users")
public class UserController {
	@Autowired
	UserServices userServices;

	@GetMapping("/exists/{username}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity<Boolean> isUsernameExists(@PathVariable String username) throws UserException {
		return new ResponseEntity<>(userServices.isUsernameExists(username), HttpStatus.OK);
	}

	@PostMapping("/update")
	@ResponseStatus(HttpStatus.ACCEPTED)
	public ResponseEntity<User> updateUser(@RequestBody UpdateUserDto updateUserDto, HttpServletRequest httpServletRequest) throws UserException {
		return new ResponseEntity<>(userServices.updateUser(updateUserDto, httpServletRequest), HttpStatus.ACCEPTED);
	}

}
