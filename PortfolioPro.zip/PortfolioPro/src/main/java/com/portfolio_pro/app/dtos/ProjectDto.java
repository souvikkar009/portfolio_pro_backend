package com.portfolio_pro.app.dtos;

public class ProjectDto {
	private String projectName;
	private String description;
	private String link;
	private String technologies; // comma separated tech stack items
	
	public ProjectDto() {}

	public ProjectDto(String projectName, String description, String link, String technologies) {
		this.projectName = projectName;
		this.description = description;
		this.link = link;
		this.technologies = technologies;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getTechnologies() {
		return technologies;
	}

	public void setTechnologies(String technologies) {
		this.technologies = technologies;
	}
	
	
	
	
	
	
}
