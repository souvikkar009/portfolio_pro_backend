package com.portfolio_pro.app.services;

import java.util.List;

import com.portfolio_pro.app.dtos.CreateFirstPortfolioDto;
import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Portfolio;

import jakarta.servlet.http.HttpServletRequest;

public interface PortfolioServices {
	public Portfolio createFirstPortfolio(CreateFirstPortfolioDto createPortfolioDto, HttpServletRequest httpServletRequest) throws PortfolioException, UserException;
	public List<Portfolio> getPortfoliosByUsername(HttpServletRequest httpServletRequest) throws UserException, PortfolioException;
	public Portfolio getPortfolioByUserAndPorfolioId(Long portfolioId, HttpServletRequest httpServletRequest) throws UserException, PortfolioException;
	public String deletePortfolioByUserAndPortfolioId(Long portfolioId, HttpServletRequest httpServletRequest) throws UserException, PortfolioException;
}
