package com.portfolio_pro.app.serviceimps;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.dtos.UpdateUserDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.repositories.UserRepository;
import com.portfolio_pro.app.services.UserServices;
import com.portfolio_pro.app.utils.AuthUtil;
import com.portfolio_pro.app.utils.ModelMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class UserServicesImp implements UserServices{
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	AuthUtil authUtil;

	@Override
	public boolean isUsernameExists(String username) {
		return userRepository.existsByUsername(username);
	}


	@Override
	public User updateUser(UpdateUserDto updateUserDto, HttpServletRequest httpServletRequest) throws UserException {
		String username = null;
		try {
			username = authUtil.extractUsernameFromRequest(httpServletRequest);
		} catch (ServletException e) {
			e.printStackTrace();
		}
		
		Optional<User> user = userRepository.findByUsername(username);
		if(user.isEmpty()) {
			throw new UserException("User Does Not Exists");
		}
		User updatedUserData = ModelMapper.mapUserDtoToUser(user.get(), updateUserDto);
		User updatedUser = userRepository.save(updatedUserData);
		if(updatedUser == null) {
			throw new UserException("User Update Failed");
		}
		return updatedUser;
	}


}
