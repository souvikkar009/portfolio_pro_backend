package com.portfolio_pro.app.dtos;

import java.time.LocalDateTime;

public class ErrorDetails {
	private String errorMessage;
	private String errorDetails;
	private LocalDateTime errorTimestamp;
	
	public ErrorDetails() {}

	public ErrorDetails(String errorMessage, String errorDetails, LocalDateTime errorTimestamp) {
		this.errorMessage = errorMessage;
		this.errorDetails = errorDetails;
		this.errorTimestamp = errorTimestamp;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

	public LocalDateTime getErrorTimestamp() {
		return errorTimestamp;
	}

	public void setErrorTimestamp(LocalDateTime errorTimestamp) {
		this.errorTimestamp = errorTimestamp;
	}
	
}
