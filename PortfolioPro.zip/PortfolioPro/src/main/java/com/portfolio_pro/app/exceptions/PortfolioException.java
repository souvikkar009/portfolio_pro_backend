package com.portfolio_pro.app.exceptions;

public class PortfolioException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public PortfolioException(String message) {
		super(message);
	}
	
}
