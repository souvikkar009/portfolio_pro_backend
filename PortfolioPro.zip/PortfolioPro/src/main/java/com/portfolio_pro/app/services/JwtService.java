package com.portfolio_pro.app.services;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.dtos.UserSigninDto;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtService {
	

	@Value("${jwt.secret}")
	private String secretKey;


	public String generateToken(UserSigninDto userSigninDto) {
		Map<String, Object> claims = new HashMap<>();
		claims.put("role", "USER");
		return Jwts
				.builder()
				.claims()
				.add(claims)
				.subject(userSigninDto.getUsername())
				.issuer("XERK").issuedAt(new Date(System.currentTimeMillis()))
				.expiration(new Date(System.currentTimeMillis() + 60*10*1000))
				.and()
				.signWith(generateKey())
				.compact();
		
	}

	private SecretKey generateKey() {
		byte[] decode = Decoders.BASE64.decode(getSecretKey());
		return Keys.hmacShaKeyFor(decode);
	}

	public String getSecretKey() {
		return secretKey;
	}


	public boolean isTokenValid(String jwt, UserDetails userDetails) {
		final String username = extractUsername(jwt);
		return (userDetails.getUsername().equals(username) && !isTokenExpired(jwt));
	}

	private boolean isTokenExpired(String jwt) {
		return extractExpiration(jwt).before(new Date());
	}

	private Date extractExpiration(String jwt) {
		return extractClaims(jwt, Claims::getExpiration);
	}

	public String extractUsername(String jwt) {
		return extractClaims(jwt, Claims::getSubject);
	}

	private <T> T extractClaims(String jwt, Function<Claims, T> claimResolver) {
		Claims claims = extractClaims(jwt);
		return claimResolver.apply(claims);
	}

	private Claims extractClaims(String jwt) {
		return Jwts.parser().verifyWith(generateKey()).build().parseSignedClaims(jwt).getPayload();
	}
}
