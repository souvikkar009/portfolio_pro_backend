package com.portfolio_pro.app.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.models.User;

@Repository
public interface PortfolioRepository extends JpaRepository<Portfolio, Long>{
	@SuppressWarnings("unchecked")
	public Portfolio save(Portfolio portfolio);
	
	public List<Portfolio> findByUser(User user);
	
	public Optional<Portfolio> findByUserAndPortfolioId(User user, Long portfolioId);

}
