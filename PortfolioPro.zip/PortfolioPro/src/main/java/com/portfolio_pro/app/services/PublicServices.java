package com.portfolio_pro.app.services;

import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Portfolio;

public interface PublicServices {
	public Portfolio getPortfolioByUsernameAndPortfolioId(String username, Long portfolioId) throws UserException, PortfolioException;
}
