package com.portfolio_pro.app.repositories;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.portfolio_pro.app.models.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{
	public boolean existsByUsername(String username);
	
	public boolean existsByEmail(String email);
	
	public Optional<User> findByUsername(String username);
	
	@SuppressWarnings("unchecked")
	public User save(User user);
}
