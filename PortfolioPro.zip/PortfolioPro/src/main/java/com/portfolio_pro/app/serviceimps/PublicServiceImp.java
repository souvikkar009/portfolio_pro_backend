package com.portfolio_pro.app.serviceimps;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.repositories.PortfolioRepository;
import com.portfolio_pro.app.repositories.UserRepository;
import com.portfolio_pro.app.services.PublicServices;


@Service
public class PublicServiceImp implements PublicServices{
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	PortfolioRepository portfolioRepository;

	@Override
	public Portfolio getPortfolioByUsernameAndPortfolioId(String username, Long portfolioId)
			throws UserException, PortfolioException {
		Optional<User> user = userRepository.findByUsername(username);
		if(user.isEmpty()) {
			throw new UserException("User Does Not Exists");
		}
		Optional<Portfolio> portfolio = portfolioRepository.findByUserAndPortfolioId(user.get(), portfolioId);
		if(portfolio.isEmpty()) {
			throw new UserException("Portfolio Does Not Exists");
		}
		return portfolio.get();
	}

	

}
