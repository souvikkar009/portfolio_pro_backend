package com.portfolio_pro.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.portfolio_pro.app.models.Education;

@Repository
public interface EducationRepository extends JpaRepository<Education, Long>{

}
