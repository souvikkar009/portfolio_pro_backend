package com.portfolio_pro.app.utils;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.dtos.UserSigninDto;
import com.portfolio_pro.app.services.JwtService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;

@Service
public class AuthUtil {
	@Autowired
	JwtService jwtService;
	
	public Cookie generateCookie(UserSigninDto userSigninDto) {
		String token = jwtService.generateToken(userSigninDto);
		
		Cookie cookie = new Cookie("AuthCookie", token);
		cookie.setHttpOnly(true);
		cookie.setSecure(true);
		cookie.setPath("/");
		cookie.setMaxAge(86400);
		cookie.setAttribute("SameSite", "None");
		
		return cookie;
	}
	
	public String extractUsernameFromRequest(HttpServletRequest httpServletRequest) throws ServletException {
		String token = Arrays.stream(httpServletRequest.getCookies())
		        .filter(cookie -> cookie.getName().equals("AuthCookie"))
		        .findFirst()
		        .map(Cookie::getValue)
		        .orElse(null);
		if(token.isEmpty()) {
			throw new ServletException("AuthToken not found");
		}
		
		String username = jwtService.extractUsername(token);
		return username;
	}
	
	public String extractTokenFromRequest(HttpServletRequest httpServletRequest) throws ServletException{
		String token = Arrays.stream(httpServletRequest.getCookies())
		        .filter(cookie -> cookie.getName().equals("AuthCookie"))
		        .findFirst()
		        .map(Cookie::getValue)
		        .orElse(null);
		if(token.isEmpty()) {
			throw new ServletException("AuthToken not found");
		}
		return token;
	}
}
