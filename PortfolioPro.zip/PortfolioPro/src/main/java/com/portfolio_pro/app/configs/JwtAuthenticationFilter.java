package com.portfolio_pro.app.configs;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.portfolio_pro.app.services.JwtService;
import com.portfolio_pro.app.utils.AuthUtil;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	@Autowired
	JwtService jwtService;
	
	@Autowired
	UserDetailsService userDetailsService;
	
	@Autowired
	AuthUtil authUtil;

	

	@Override
	protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain)
			throws ServletException, IOException {

		Cookie[] cookies = httpServletRequest.getCookies();
		if(cookies == null) {
			filterChain.doFilter(httpServletRequest, httpServletResponse);
			return;
		}
		String authCookie = "";
		for(Cookie cookie: cookies) {
			if(cookie.getName().equals("AuthCookie")) {
				authCookie = cookie.getValue();
			}
		}
		if (authCookie.isEmpty()) {
			filterChain.doFilter(httpServletRequest, httpServletResponse);
			System.out.println("Lol");
			return;
		}
		

		final String jwt = authCookie;
		final String username = jwtService.extractUsername(jwt);
		

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (username != null && authentication == null) {
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);
			
			System.out.println(userDetails.getUsername());

			if (jwtService.isTokenValid(jwt, userDetails)) {
				UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails, null, userDetails.getAuthorities());
				authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(httpServletRequest));

				SecurityContextHolder.getContext().setAuthentication(authenticationToken);
			}

		}

		filterChain.doFilter(httpServletRequest, httpServletResponse);
	}

}
