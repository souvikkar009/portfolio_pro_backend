package com.portfolio_pro.app.services;

import com.portfolio_pro.app.dtos.UserSigninDto;
import com.portfolio_pro.app.dtos.UserSignupDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;

import jakarta.servlet.http.HttpServletResponse;

public interface AuthServices {
	public User signupUser(UserSignupDto userSignupDto) throws UserException;
	public String signinUser(UserSigninDto userSigninDto, HttpServletResponse httpServletResponse) throws UserException;
}
