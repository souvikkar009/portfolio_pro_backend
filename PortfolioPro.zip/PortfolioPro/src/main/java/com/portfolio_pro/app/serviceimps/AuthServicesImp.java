package com.portfolio_pro.app.serviceimps;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.dtos.UserSigninDto;
import com.portfolio_pro.app.dtos.UserSignupDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.repositories.UserRepository;
import com.portfolio_pro.app.services.AuthServices;
import com.portfolio_pro.app.services.JwtService;
import com.portfolio_pro.app.utils.AuthUtil;
import com.portfolio_pro.app.utils.ModelMapper;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class AuthServicesImp implements AuthServices {
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	UserRepository userRepository;

	@Autowired
	AuthenticationManager authenticationManager;
	
	@Autowired
	JwtService jwtService;
	
	@Autowired
	AuthUtil authUtil;

	@Override
	public User signupUser(UserSignupDto userSignupDto) throws UserException{
		if(userRepository.existsByEmail(userSignupDto.getEmail())) {
			throw new UserException("Email is already in use");
		}
		if(userRepository.existsByUsername(userSignupDto.getUsername())) {
			throw new UserException("Username is already taken");
		}
		User user = ModelMapper.toUserFromUserSignupDto(userSignupDto);
		user.setPassword(bCryptPasswordEncoder.encode(userSignupDto.getPassword()));
		return userRepository.save(user);
	}

	@Override
	public String signinUser(UserSigninDto userSigninDto, HttpServletResponse httpServletResponse) throws UserException{
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(userSigninDto.getUsername(), userSigninDto.getPassword()));

		
		if(authentication.isAuthenticated()) {
			
			Cookie cookie = authUtil.generateCookie(userSigninDto);
	        httpServletResponse.addCookie(cookie);
	        return "success";
		}

		return "failure";
	}

}
