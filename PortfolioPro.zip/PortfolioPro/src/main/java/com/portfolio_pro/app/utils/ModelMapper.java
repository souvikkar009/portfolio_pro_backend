package com.portfolio_pro.app.utils;

import org.springframework.beans.factory.annotation.Autowired;

import com.portfolio_pro.app.dtos.CreateFirstPortfolioDto;
import com.portfolio_pro.app.dtos.ExperienceDto;
import com.portfolio_pro.app.dtos.ProjectDto;
import com.portfolio_pro.app.dtos.UpdateUserDto;
import com.portfolio_pro.app.dtos.UserSignupDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Experience;
import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.models.Project;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.repositories.UserRepository;
import com.portfolio_pro.app.services.JwtService;

public class ModelMapper {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	JwtService jwtService;

	public static User toUserFromUserSignupDto(UserSignupDto userSignupDto) {
		User user = new User();

		user.setUsername(userSignupDto.getUsername());
		user.setEmail(userSignupDto.getEmail());
		user.setFullName(userSignupDto.getFullName());
//		user.setPassword( userSignupDto.getPassword());

		return user;
	}

	public static Portfolio toPortfolioFromCreateFirstPortfolioDto(CreateFirstPortfolioDto createFirstPortfolioDto)
			throws UserException {
		Portfolio portfolio = new Portfolio();

		portfolio.setPortfolioTitle(createFirstPortfolioDto.getPortfolioTitle());
		portfolio.setBio(createFirstPortfolioDto.getBio());
		portfolio.setAbout(createFirstPortfolioDto.getAbout());
		portfolio.setProfessionalIdentity(createFirstPortfolioDto.getProfessionalIdentity());
		portfolio.setProfilePhotoUrl(createFirstPortfolioDto.getProfilePhotoUrl());
		portfolio.setSkills(createFirstPortfolioDto.getSkills());

		return portfolio;
	}

	public static Experience toExperienceFromExperienceDto(ExperienceDto experienceDto) {
		Experience experience = new Experience();

		experience.setCompany(experienceDto.getCompany());
		experience.setJobTitle(experienceDto.getJobTitle());
		experience.setDescription(experienceDto.getDescription());
		experience.setStartingDate(experienceDto.getStartingDate());
		experience.setEndingDate(experienceDto.getEndingDate());

		return experience;
	}

	public static Project toProjectFromProjectDto(ProjectDto projectDto) {
		Project project = new Project();

		project.setProjectName(projectDto.getProjectName());
		project.setDescription(projectDto.getDescription());
		project.setLink(projectDto.getLink());
		project.setTechnologies(projectDto.getTechnologies());

		return project;
	}


	public static User mapUserDtoToUser(User user, UpdateUserDto updateUserDto) {

		if (updateUserDto.getUsername() != null) {
			user.setUsername(updateUserDto.getUsername());
		}
		if (updateUserDto.getEmail() != null) {
			user.setEmail(updateUserDto.getEmail());
		}
		if (updateUserDto.getPassword() != null) {
			user.setPassword(updateUserDto.getPassword());
		}
		if (updateUserDto.getFullName() != null) {
			user.setFullName(updateUserDto.getFullName());
		}
		if (updateUserDto.getPhoneNo() != null) {
			user.setPhoneNo(updateUserDto.getPhoneNo());
		}
		if (updateUserDto.getLocation() != null) {
			user.setLocation(updateUserDto.getLocation());
		}
		if (updateUserDto.getActivePortfolio() != null) {
			user.setActivePortfolio(updateUserDto.getActivePortfolio());
		}
		if (updateUserDto.getEducations() != null) {
			user.setEducations(updateUserDto.getEducations());
		}
		if (updateUserDto.getSocialLinks() != null) {
			user.setSocialLinks(updateUserDto.getSocialLinks());
		}
		
		return user;
	}
}
