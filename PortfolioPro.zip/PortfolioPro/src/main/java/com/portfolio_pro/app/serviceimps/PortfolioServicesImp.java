package com.portfolio_pro.app.serviceimps;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.portfolio_pro.app.dtos.CreateFirstPortfolioDto;
import com.portfolio_pro.app.dtos.ExperienceDto;
import com.portfolio_pro.app.dtos.ProjectDto;
import com.portfolio_pro.app.exceptions.PortfolioException;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.Experience;
import com.portfolio_pro.app.models.Portfolio;
import com.portfolio_pro.app.models.Project;
import com.portfolio_pro.app.models.User;
import com.portfolio_pro.app.repositories.ExperienceRepositry;
import com.portfolio_pro.app.repositories.PortfolioRepository;
import com.portfolio_pro.app.repositories.ProjectRepository;
import com.portfolio_pro.app.repositories.UserRepository;
import com.portfolio_pro.app.services.JwtService;
import com.portfolio_pro.app.services.PortfolioServices;
import com.portfolio_pro.app.utils.AuthUtil;
import com.portfolio_pro.app.utils.ModelMapper;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;

@Service
public class PortfolioServicesImp implements PortfolioServices {

	@Autowired
	ProjectRepository projectRepository;

	@Autowired
	UserRepository userRepository;

	@Autowired
	PortfolioRepository portfolioRepository;

	@Autowired
	ExperienceRepositry experienceRepositry;

	@Autowired
	JwtService jwtService;

	@Autowired
	AuthUtil authUtil;

	@Override
	@Transactional
	public Portfolio createFirstPortfolio(CreateFirstPortfolioDto createFirstPortfolioDto,
			HttpServletRequest httpServletRequest) throws PortfolioException, UserException {

		String username = null;
		try {
			username = authUtil.extractUsernameFromRequest(httpServletRequest);
		} catch (ServletException e) {
			e.printStackTrace();
		}

		Optional<User> user = userRepository.findByUsername(username);

		if (user.isEmpty()) {
			throw new UserException("User not available by username " + username);
		}

		Portfolio portfolio = ModelMapper.toPortfolioFromCreateFirstPortfolioDto(createFirstPortfolioDto);

		portfolio.setUser(user.get());

		Portfolio newPortfolio = portfolioRepository.save(portfolio);

		User currUser = user.get();
		currUser.setActivePortfolio(newPortfolio);
		User updatedUser = userRepository.save(currUser);

		if (updatedUser == null) {
			throw new UserException("Failed to update active portfolio.");
		}

		List<ExperienceDto> experienceDtos = createFirstPortfolioDto.getExperienceDtos();
		List<ProjectDto> projectDtos = createFirstPortfolioDto.getProjectDtos();

		for (ExperienceDto experienceDto : experienceDtos) {
			Experience experience = ModelMapper.toExperienceFromExperienceDto(experienceDto);
			experience.setPortfolio(newPortfolio);
			experienceRepositry.save(experience);
		}

		for (ProjectDto projectDto : projectDtos) {
			Project project = ModelMapper.toProjectFromProjectDto(projectDto);
			project.setPortfolio(newPortfolio);
			projectRepository.save(project);
		}

		newPortfolio = portfolioRepository.save(newPortfolio);

		if (newPortfolio == null) {
			throw new PortfolioException("Failed to Create Portfolio");
		}

		return newPortfolio;
	}

	@Override
	public List<Portfolio> getPortfoliosByUsername(HttpServletRequest httpServletRequest)
			throws UserException, PortfolioException {
		String username = null;
		try {
			username = authUtil.extractUsernameFromRequest(httpServletRequest);
		} catch (ServletException e) {
			e.printStackTrace();
		}

		Optional<User> user = userRepository.findByUsername(username);
		if (user.isEmpty()) {
			throw new UserException("User Does Not Exist");
		}
		List<Portfolio> portfolios = portfolioRepository.findByUser(user.get());
		return portfolios;
	}

	@Override
	public Portfolio getPortfolioByUserAndPorfolioId(Long portfolioId, HttpServletRequest httpServletRequest)
			throws UserException, PortfolioException {
		String username = null;
		try {
			username = authUtil.extractUsernameFromRequest(httpServletRequest);
		} catch (ServletException e) {
			e.printStackTrace();
		}

		Optional<User> user = userRepository.findByUsername(username);

		if (user.isEmpty()) {
			throw new UserException("User Does Not Exist");
		}

		Optional<Portfolio> portfolio = portfolioRepository.findByUserAndPortfolioId(user.get(), portfolioId);

		if (portfolio.isEmpty()) {
			throw new PortfolioException("Portfolio Does Not Exist");
		}
		return portfolio.get();

	}

	@Override
	@Transactional
	public String deletePortfolioByUserAndPortfolioId(Long portfolioId, HttpServletRequest httpServletRequest)
			throws UserException, PortfolioException {
		String username = null;
		try {
			username = authUtil.extractUsernameFromRequest(httpServletRequest);
		} catch (ServletException e) {
			e.printStackTrace();
		}

		Optional<User> user = userRepository.findByUsername(username);

		if (user.isEmpty()) {
			throw new UserException("User Does Not Exist");
		}
		
		Optional<Portfolio> portfolio = portfolioRepository.findById(portfolioId);
		
		if(portfolio.isEmpty()) {
			throw new PortfolioException("Portfolio Does Not Exists");
		}
		
		
		
		if(!portfolio.get().getUser().getUsername().equals(username)) {
			throw new UserException("User Not Authorized");
		}
		
		portfolio.get().setProjects(null);
		portfolio.get().setExperiences(null);

		portfolioRepository.delete(portfolio.get());

		return "Portfolio Deleted Successfully";
	}

}
