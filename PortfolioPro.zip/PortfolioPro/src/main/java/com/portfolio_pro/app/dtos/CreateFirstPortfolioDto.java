package com.portfolio_pro.app.dtos;


import java.util.List;

public class CreateFirstPortfolioDto {
	
//	portfolio data
	private String portfolioTitle;
	private String about;
	private String bio;
	private String professionalIdentity;
	private String profilePhotoUrl;
	private String skills;
	
	List<ExperienceDto> experienceDtos;
	
	List<ProjectDto> projectDtos;
	
	
	public CreateFirstPortfolioDto() {}

	public CreateFirstPortfolioDto(String portfolioTitle, String about, String bio, String professionalIdentity,
			String profilePhotoUrl, String skills, List<ExperienceDto> experienceDtos, List<ProjectDto> projectDtos) {
		this.portfolioTitle = portfolioTitle;
		this.about = about;
		this.bio = bio;
		this.professionalIdentity = professionalIdentity;
		this.profilePhotoUrl = profilePhotoUrl;
		this.experienceDtos = experienceDtos;
		this.projectDtos = projectDtos;
		this.skills = skills;
	}

	public String getPortfolioTitle() {
		return portfolioTitle;
	}

	public void setPortfolioTitle(String portfolioTitle) {
		this.portfolioTitle = portfolioTitle;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getProfessionalIdentity() {
		return professionalIdentity;
	}

	public void setProfessionalIdentity(String professionalIdentity) {
		this.professionalIdentity = professionalIdentity;
	}

	public String getProfilePhotoUrl() {
		return profilePhotoUrl;
	}

	public void setProfilePhotoUrl(String profilePhotoUrl) {
		this.profilePhotoUrl = profilePhotoUrl;
	}

	public List<ExperienceDto> getExperienceDtos() {
		return experienceDtos;
	}

	public void setExperienceDtos(List<ExperienceDto> experienceDtos) {
		this.experienceDtos = experienceDtos;
	}

	public List<ProjectDto> getProjectDtos() {
		return projectDtos;
	}

	public void setProjectDtos(List<ProjectDto> projectDtos) {
		this.projectDtos = projectDtos;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}
	
}
