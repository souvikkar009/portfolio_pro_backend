package com.portfolio_pro.app.services;

import com.portfolio_pro.app.dtos.UpdateUserDto;
import com.portfolio_pro.app.exceptions.UserException;
import com.portfolio_pro.app.models.User;

import jakarta.servlet.http.HttpServletRequest;

public interface UserServices {
	 public boolean isUsernameExists(String username);
//	 public boolean changeUsername(String username) throws UserException;
	 public User updateUser(UpdateUserDto updateUserDto, HttpServletRequest httpServletRequest) throws UserException;
}
