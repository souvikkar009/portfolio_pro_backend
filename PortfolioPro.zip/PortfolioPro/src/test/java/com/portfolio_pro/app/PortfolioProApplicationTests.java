package com.portfolio_pro.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioProApplicationTests {

	@Test
	void contextLoads() {
	}

}
